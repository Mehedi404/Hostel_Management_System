<?php
$conn= mysqli_connect('localhost','root','','hms') or die("Connection failed:" .mysqli_connect_error());

return $conn;

 ?>
